int main(){
 int a,b,c;
 a=45;
 b=45;
 c = a<45; 
 return c;
}