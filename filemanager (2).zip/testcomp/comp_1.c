int main(){
 int a,b,c;
 a=23;
 b=59;
 c = 23>59; 
 return c;
}