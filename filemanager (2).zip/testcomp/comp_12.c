int main(){
 int a,b,c;
 a=23;
 b=59;
 c = 23<b; 
 return c;
}