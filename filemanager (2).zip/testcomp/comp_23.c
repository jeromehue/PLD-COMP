int main(){
 int a,b,c;
 a=45;
 b=45;
 c = 45!=b; 
 return c;
}